import sys
sys.path.insert(0, '/project')
from app import app as application

export http_proxy=
export https_proxy=
export no_proxy=