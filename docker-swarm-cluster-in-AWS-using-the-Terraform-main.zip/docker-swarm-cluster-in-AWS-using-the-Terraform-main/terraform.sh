#!/usr/bin/env bash

docker run --rm -v $PWD:/data amontaigu/terraform $*